# ussreconomy

## Generate HTML

* Open RStudio
* Open plots.Rmd
* Click the "Knit" button on top of the code editor.
* plots.html will be gemnerated and placed in the root folder
* HTML file is ready to be open and shared

